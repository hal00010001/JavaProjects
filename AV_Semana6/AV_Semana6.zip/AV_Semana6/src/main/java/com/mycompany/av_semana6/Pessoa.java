
package com.mycompany.av_semana6;

/**
 *
 * @author Almir L. Bindo
 */
public class Pessoa {
    
    double peso = 0;
    double altura = 0;

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
            
}
