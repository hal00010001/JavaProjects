/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.av_semana6;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Almir L. Bindo
 */
public class Controller {
    
    public List<Pessoa> getDataIMC(){
        List<Pessoa> lista = new ArrayList();
        Scanner captura = null;
        Scanner captura2 = null;
        Pessoa dao = new Pessoa();
        System.out.println("Digite o seu peso:");
        captura = new Scanner(System.in);
        double peso = Double.parseDouble(captura.next());
        dao.setPeso(peso);        
        System.out.println("Digite a sua altura:");
        captura2 = new Scanner(System.in);
        double altura = Double.parseDouble(captura2.next());
        dao.setAltura(altura);
        lista.add(dao);
        return lista;
    }
    
    public String doCalcIMC(){        
        double peso = 0;
        double altura = 0;
        List<Pessoa> lista = this.getDataIMC();        
        for (Pessoa bean : lista){
            peso = bean.getPeso();
            altura = bean.getAltura();
        }
        double imc = (peso)/(altura*altura);
        DecimalFormat df = new DecimalFormat("#.##");
        if (imc < 18.5){
            return df.format((peso)/(altura*altura))+" e você está abaixo do peso.";
        }
        else if (imc > 18.5 && imc < 25){
            return df.format((peso)/(altura*altura))+" e você está com o peso normal";
        }
        else if (imc >= 25 && imc < 30){
            return df.format((peso)/(altura*altura))+" e você está com sobrepeso";
        }
        else if (imc >= 30){
            return df.format((peso)/(altura*altura))+" e você está com obesidade";
        }
        else {
            return null;
        }
        
    }
    
}
