package af_semana9;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {   
        
    //String patternString = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\\\[[0-9]{1,3}\\\\.[0-9]{1,3}\\\\.[0-9]{1,3}\\\\.[0-9]{1,3}\\\\])|(([a-zA-Z\\\\-0-9]+\\\\.)+[a-zA-Z]{2,}))";
    private static final String patternString = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    private static final Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
    
    public boolean validarEmail(String email){
        Matcher match = pattern.matcher(email);
        return match.matches();
    }
    
    public Cliente cadastrarCliente(){
        List<Cliente> lista = new ArrayList<Cliente>();
        DateFormat formato = new SimpleDateFormat("dd/mm/yy");
        Cliente pojo = new Cliente();
        System.out.println("Entre com o nome do Cliente:");
        Scanner nome = new Scanner(System.in);
        pojo.setNome(nome.next());
        System.out.println("Entre com o sobrenome do Cliente:");
        Scanner sobrenome = new Scanner(System.in);
        pojo.setSobrenome(sobrenome.next());
        System.out.println("Entre com a data de nascimento do Cliente (dd/mm/aa):");
        Scanner dataNascimento = new Scanner(System.in);
        try {
            pojo.setDataNascimento(new Date(formato.parse(dataNascimento.next()).getTime()));
        } catch (ParseException ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Entre com o id do Cliente:");
        Scanner id = new Scanner(System.in);
        pojo.setIdCliente(Integer.parseInt(id.next()));
        System.out.println("Entre com o e-mail do Cliente");
        Scanner email = new Scanner(System.in);
        String emailString = email.next();
        while (!validarEmail(emailString)){
            System.out.println("Entre com o e-mail do Cliente:");
            email = new Scanner(System.in);
            emailString = email.next();
        }
        pojo.setEmail(emailString);
        System.out.println("Cliente cadastrado com sucesso.");
        return pojo;
    }
    
    public Funcionario cadastrarFuncionario(){
        List<Funcionario> lista = new ArrayList<Funcionario>();
        DateFormat formato = new SimpleDateFormat("dd/mm/yy");
        Funcionario pojo = new Funcionario();
        System.out.println("Entre com o nome do Funcionário:");
        Scanner nome = new Scanner(System.in);
        pojo.setNome(nome.next());
        System.out.println("Entre com o sobrenome do Funcionário:");
        Scanner sobrenome = new Scanner(System.in);   
        pojo.setSobrenome(sobrenome.next());
        System.out.println("Entre com a data de nascimento do Funcionário (dd/mm/aa):");
        Scanner dataNascimento = new Scanner(System.in);
        try {
            pojo.setDataNascimento(new Date(formato.parse(dataNascimento.next()).getTime()));
        } catch (ParseException ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Entre com o id do Funcionário:");
        Scanner id = new Scanner(System.in);
        pojo.setIdFuncionario(Integer.parseInt(id.next()));
        System.out.println("Entre com o cargo do Funcionário");
        Scanner cargo = new Scanner(System.in);
        pojo.setCargo(cargo.next());
        System.out.println("Entre com o salário do Funcionário:");
        Scanner salario = new Scanner(System.in);
        pojo.setSalario(salario.nextFloat());
        System.out.println("Entre com a data de contratação do Funcionário:");
        Scanner dataContratacao = new Scanner(System.in);
        try {
            pojo.setDataContratacao(new Date(formato.parse(dataContratacao.next()).getTime()));
        } catch (ParseException ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Funcionário cadastrado com sucesso!");
        return pojo;
    }
    
}
