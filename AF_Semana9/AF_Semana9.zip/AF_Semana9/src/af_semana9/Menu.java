package af_semana9;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {

    public static void main(String[] args) {
        
        List<Cliente> clientes = new ArrayList<>();
        List<Funcionario> funcionarios = new ArrayList<>();
              
        
        Scanner menu = null;
        System.out.println("==============================");
        System.out.println("            Menu          ");
        System.out.println("==============================");
        System.out.println("1. Cadastrar um cliente");
        System.out.println("2. Cadastrar um Funcionário");
        System.out.println("3. Sair");
        System.out.println("==============================");
               
        menu = new Scanner(System.in);
        String menuString = menu.next();
                
        while (!menuString.equals("3")){                         
            if (menuString.equals("1")) {
                Util dao = new Util();
                System.out.println("Cadastro de novo Cliente");
                clientes.add(dao.cadastrarCliente());
                for (Cliente pojo:clientes){
                    System.out.println("============================");
                    System.out.println("Cliente ID: "+pojo.getIdCliente());
                    System.out.println("Nome: "+pojo.getNome()+" "+pojo.getSobrenome());
                    System.out.println("Data de Nascimento: "+pojo.getDataNascimento());                    
                    System.out.println("E-mail: "+pojo.getEmail());
                    System.out.println("============================");
                }
            }
            else if (menuString.equals("2")) {
                Util dao = new Util();
                System.out.println("Cadastro de novo Funcionário");
                funcionarios.add(dao.cadastrarFuncionario());
                for (Funcionario pojo:funcionarios){
                    System.out.println("============================");
                    System.out.println("Funcionário ID: "+pojo.getIdFuncionario());
                    System.out.println("Nome: "+pojo.getNome()+" "+pojo.getSobrenome());
                    System.out.println("Data de Nascimento: "+pojo.getDataNascimento());                    
                    System.out.println("Cargo: "+pojo.getCargo());
                    System.out.println("Salário: "+pojo.getSalario());
                    System.out.println("Data de Contratação: "+pojo.getDataContratacao());
                    System.out.println("============================");
                }
            }
            else if (menuString.equals("3")){
                System.exit(0);
            }
            else {
                System.out.println("Favor selecionar somente as opções válidas.");
            }
            menu = null;
            System.out.println("==========================");
            System.out.println("            Menu          ");
            System.out.println("==========================");
            System.out.println("1. Cadastrar um cliente");
            System.out.println("2. Cadastrar um Funcionário");
            System.out.println("3. Sair");
            System.out.println("==========================");

            menu = new Scanner(System.in);
            menuString = menu.next();
        }
                
    }
    
}
