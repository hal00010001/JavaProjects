package calculo;

public class Calculo {
    
    public static int Soma(int a, int b){
        int res = a + b;
        return res;
    }
    static int Subtracao(int a, int b){
        int res = a -b;
        return res;
    }
    static int Multiplicacao(int a, int b){
        int res = a * b;
        return res;
    }
    static float Divisao(float a, float b){
        float res = a / b;
        return res;
    }
    
}
