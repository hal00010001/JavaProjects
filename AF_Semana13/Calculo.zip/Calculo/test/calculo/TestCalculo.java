
package calculo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class TestCalculo {
    
    public TestCalculo() {
    }
    @Test
    public void TestSoma(){
        System.out.println("Soma");
        int a = 10;
        int b = 20;
        int expResult = 30;
        int result = Calculo.Soma(a, b);
        assertEquals(expResult, result);        
    }
    @Test
    public void TestSubtracao(){
        System.out.println("Subtração");
        int a = 20;
        int b = 10;
        int expResult = 10;
        int result = Calculo.Subtracao(a, b);
        assertEquals(expResult, result);        
    }
    @Test
    public void TestMultiplicacao(){
        System.out.println("Multiplicação");
        int a = 5;
        int b = 10;
        int expResult = 50;
        int result = Calculo.Multiplicacao(a, b);
        assertEquals(expResult, result);        
    }
    @Test
    public void TestDivisao(){
        System.out.println("Divisão");
        float a = 20;
        float b = 10;
        float expResult = 2;
        float result = Calculo.Divisao(a, b);
        assertEquals(expResult, result);        
    }
    
}
