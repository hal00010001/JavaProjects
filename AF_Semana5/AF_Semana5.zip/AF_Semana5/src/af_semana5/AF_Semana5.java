package af_semana5;

import java.util.Scanner;

/**
 *
 * @author Almir L. Bindo
 */
public class AF_Semana5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int n1 = 0;
        Scanner captura = new Scanner(System.in);
        
        System.out.print("Digite o valor que deseja verificar o desconto:  ");
        n1 = captura.nextInt();
                
        Metodos mtd = new Metodos();
        
        System.out.println(mtd.main(n1));
               
    }    

}
