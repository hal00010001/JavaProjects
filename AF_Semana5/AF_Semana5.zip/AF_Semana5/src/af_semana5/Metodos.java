/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package af_semana5;

/**
 *
 * @author hal
 */
public class Metodos {
    
    public String main(int valor){
        return "O valor digitado com o desconto de 11% é: "+this.getDesconto(valor);
    }
    public double getDesconto(int valor){
        double valorDesconto = 0;
        valorDesconto = valor * 11 / 100;
        return valorDesconto;
    }
    
}
